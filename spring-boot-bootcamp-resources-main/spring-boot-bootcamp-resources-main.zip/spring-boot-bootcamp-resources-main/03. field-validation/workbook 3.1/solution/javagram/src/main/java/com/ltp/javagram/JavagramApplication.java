package com.ltp.javagram;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavagramApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavagramApplication.class, args);
	}

}
