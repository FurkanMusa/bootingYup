package com.ltp.globalsuperstore;

public class Constants {
    public static final String[] CATEGORIES = new String[] {"Furniture", "Office Supplies", "Technology"};
}
