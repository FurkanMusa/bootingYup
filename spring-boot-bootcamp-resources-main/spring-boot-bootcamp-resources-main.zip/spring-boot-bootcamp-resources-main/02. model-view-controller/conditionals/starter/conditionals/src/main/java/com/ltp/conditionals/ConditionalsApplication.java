package com.ltp.conditionals;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConditionalsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConditionalsApplication.class, args);
	}

}
