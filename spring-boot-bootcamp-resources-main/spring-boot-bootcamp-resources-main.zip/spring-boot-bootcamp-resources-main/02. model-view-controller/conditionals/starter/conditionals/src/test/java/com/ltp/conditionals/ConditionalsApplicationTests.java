package com.ltp.conditionals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConditionalsApplicationTests {

	@Test
	void contextLoads() {
	}

}
